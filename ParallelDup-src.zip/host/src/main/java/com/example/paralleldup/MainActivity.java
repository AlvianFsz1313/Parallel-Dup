package com.example.paralleldup;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import top.niunaijun.blackbox.BlackBoxCore;

public class MainActivity extends Activity {
    private static class Row {
        String label; Drawable icon;
        Row(String l, Drawable i) { label = l; icon = i; }
    }

    private class RowAdapter extends BaseAdapter {
        final List<Row> rows;
        RowAdapter(List<Row> r) { rows = r; }
        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int i) { return rows.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View v, ViewGroup parent) {
            LinearLayout l = new LinearLayout(MainActivity.this);
            l.setOrientation(LinearLayout.HORIZONTAL);
            l.setGravity(Gravity.CENTER_VERTICAL);
            l.setPadding(dp(8), dp(8), dp(8), dp(8));
            ImageView iv = new ImageView(MainActivity.this);
            iv.setImageDrawable(rows.get(i).icon);
            l.addView(iv, new LinearLayout.LayoutParams(dp(48), dp(48)));
            TextView tv = new TextView(MainActivity.this);
            tv.setText(rows.get(i).label);
            tv.setTextSize(16);
            tv.setPadding(dp(14), 0, 0, 0);
            l.addView(tv);
            return l;
        }
    }

    private ListView list;
    private List<CloneStore.Clone> clones = new ArrayList<CloneStore.Clone>();

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Main.ensureService(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(12));

        TextView title = new TextView(this);
        title.setText("Parallel Dup");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        Button add = new Button(this);
        add.setText("+ Duplikat aplikasi");
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pickApp(); }
        });
        root.addView(add);

        Button bat = new Button(this);
        bat.setText("Izinkan jalan di background (baterai)");
        bat.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { requestBattery(); }
        });
        root.addView(bat);

        list = new ListView(this);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                CloneStore.Clone c = clones.get(pos);
                BlackBoxCore.get().launchApk(c.pkg, c.userId);
            }
        });
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override public boolean onItemLongClick(AdapterView<?> p, View v, int pos, long id) {
                cloneMenu(clones.get(pos));
                return true;
            }
        });
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        refresh();
    }

    private String labelOf(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) { return pkg; }
    }

    private void refresh() {
        clones = CloneStore.all(this);
        List<Row> rows = new ArrayList<Row>();
        for (CloneStore.Clone c : clones) {
            rows.add(new Row(labelOf(c.pkg) + "  #" + c.number(),
                    new BitmapDrawable(getResources(), Badge.icon(this, c.pkg, c.number()))));
        }
        list.setAdapter(new RowAdapter(rows));
    }

    private void pickApp() {
        Toast.makeText(this, "Memuat daftar aplikasi...", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override public void run() {
                final PackageManager pm = getPackageManager();
                Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> ris = pm.queryIntentActivities(q, 0);
                final List<String> pkgs = new ArrayList<String>();
                final List<Row> rows = new ArrayList<Row>();
                Collections.sort(ris, new ResolveInfo.DisplayNameComparator(pm));
                for (ResolveInfo ri : ris) {
                    String pkg = ri.activityInfo.packageName;
                    if (pkg.equals(getPackageName()) || pkgs.contains(pkg)) continue;
                    pkgs.add(pkg);
                    rows.add(new Row(String.valueOf(ri.loadLabel(pm)), ri.loadIcon(pm)));
                }
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("Pilih aplikasi")
                                .setAdapter(new RowAdapter(rows), new DialogInterface.OnClickListener() {
                                    @Override public void onClick(DialogInterface d, int which) {
                                        cloneApp(pkgs.get(which));
                                    }
                                }).show();
                    }
                });
            }
        }).start();
    }

    private void cloneApp(final String pkg) {
        final int uid = CloneStore.nextUserId(this, pkg);
        Toast.makeText(this, "Menduplikat...", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override public void run() {
                boolean ok = false;
                try {
                    BlackBoxCore.get().installPackageAsUser(pkg, uid);
                    ok = BlackBoxCore.get().isInstalled(pkg, uid);
                } catch (Throwable t) { t.printStackTrace(); }
                final boolean fin = ok;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (fin) {
                            CloneStore.add(MainActivity.this, pkg, uid);
                            refresh();
                            Toast.makeText(MainActivity.this, "Berhasil: duplikat #" + (uid + 1), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Gagal menduplikat aplikasi ini", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        }).start();
    }

    private void cloneMenu(final CloneStore.Clone c) {
        new AlertDialog.Builder(this)
                .setTitle(labelOf(c.pkg) + " #" + c.number())
                .setItems(new String[]{"Buat shortcut di home screen", "Hapus duplikat"},
                        new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int which) {
                                if (which == 0) pin(c);
                                else {
                                    try { BlackBoxCore.get().uninstallPackageAsUser(c.pkg, c.userId); } catch (Throwable ignored) { }
                                    CloneStore.remove(MainActivity.this, c.pkg, c.userId);
                                    refresh();
                                }
                            }
                        }).show();
    }

    private void pin(CloneStore.Clone c) {
        if (Build.VERSION.SDK_INT < 26) {
            Toast.makeText(this, "Shortcut butuh Android 8+", Toast.LENGTH_LONG).show();
            return;
        }
        ShortcutManager sm = getSystemService(ShortcutManager.class);
        if (sm == null || !sm.isRequestPinShortcutSupported()) {
            Toast.makeText(this, "Launcher tidak mendukung pin shortcut", Toast.LENGTH_LONG).show();
            return;
        }
        Intent i = new Intent(this, ShortcutActivity.class)
                .setAction(Intent.ACTION_VIEW)
                .putExtra("pkg", c.pkg)
                .putExtra("uid", c.userId);
        ShortcutInfo info = new ShortcutInfo.Builder(this, c.pkg + "#" + c.userId)
                .setShortLabel(labelOf(c.pkg) + " " + c.number())
                .setIcon(Icon.createWithBitmap(Badge.icon(this, c.pkg, c.number())))
                .setIntent(i)
                .build();
        sm.requestPinShortcut(info, null);
    }

    private void requestBattery() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }
}
