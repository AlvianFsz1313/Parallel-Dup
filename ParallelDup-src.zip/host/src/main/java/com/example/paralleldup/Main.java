package com.example.paralleldup;

import android.content.Context;
import android.content.Intent;
import android.os.Build;

class Main {
    static void ensureService(Context c) {
        try {
            Intent i = new Intent(c, KeepAliveService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Exception ignored) { }
    }
}
