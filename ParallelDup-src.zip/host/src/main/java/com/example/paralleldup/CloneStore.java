package com.example.paralleldup;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Menyimpan daftar klon sebagai "paket|userId". Tidak ada batas jumlah klon. */
public class CloneStore {
    public static class Clone {
        public final String pkg;
        public final int userId;
        public Clone(String pkg, int userId) { this.pkg = pkg; this.userId = userId; }
        /** Duplikat ke-berapa (mulai dari 1). */
        public int number() { return userId + 1; }
    }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("clones", Context.MODE_PRIVATE);
    }

    private static Set<String> raw(Context c) {
        return new HashSet<String>(sp(c).getStringSet("list", new HashSet<String>()));
    }

    public static List<Clone> all(Context c) {
        List<Clone> l = new ArrayList<Clone>();
        for (String s : raw(c)) {
            int i = s.lastIndexOf('|');
            l.add(new Clone(s.substring(0, i), Integer.parseInt(s.substring(i + 1))));
        }
        Collections.sort(l, new java.util.Comparator<Clone>() {
            @Override public int compare(Clone a, Clone b) {
                int r = a.pkg.compareTo(b.pkg);
                return r != 0 ? r : Integer.compare(a.userId, b.userId);
            }
        });
        return l;
    }

    public static int nextUserId(Context c, String pkg) {
        int max = -1;
        for (Clone x : all(c)) if (x.pkg.equals(pkg)) max = Math.max(max, x.userId);
        return max + 1;
    }

    public static void add(Context c, String pkg, int userId) {
        Set<String> s = raw(c);
        s.add(pkg + "|" + userId);
        sp(c).edit().putStringSet("list", s).apply();
    }

    public static void remove(Context c, String pkg, int userId) {
        Set<String> s = raw(c);
        s.remove(pkg + "|" + userId);
        sp(c).edit().putStringSet("list", s).apply();
    }
}
