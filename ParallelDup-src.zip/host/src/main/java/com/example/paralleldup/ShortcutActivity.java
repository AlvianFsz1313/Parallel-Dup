package com.example.paralleldup;

import android.app.Activity;
import android.os.Bundle;

import top.niunaijun.blackbox.BlackBoxCore;

/** Dibuka dari shortcut di home screen: langsung meluncurkan klon lalu menutup diri. */
public class ShortcutActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            Main.ensureService(this);
            String pkg = getIntent().getStringExtra("pkg");
            int uid = getIntent().getIntExtra("uid", 0);
            BlackBoxCore.get().launchApk(pkg, uid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        finish();
    }
}
