package com.example.paralleldup;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;

public class Badge {
    /** Ikon asli aplikasi + lingkaran kecil bernomor di pojok kanan bawah. */
    public static Bitmap icon(Context c, String pkg, int number) {
        Drawable d;
        try {
            d = c.getPackageManager().getApplicationIcon(pkg);
        } catch (Exception e) {
            d = c.getPackageManager().getDefaultActivityIcon();
        }
        int s = 192;
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        d.setBounds(0, 0, s, s);
        d.draw(cv);

        float r = s * 0.22f, cx = s - r, cy = s - r;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFFE53935);
        cv.drawCircle(cx, cy, r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(s * 0.03f);
        p.setColor(Color.WHITE);
        cv.drawCircle(cx, cy, r, p);

        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setColor(Color.WHITE);
        t.setTextAlign(Paint.Align.CENTER);
        t.setFakeBoldText(true);
        t.setTextSize(number > 9 ? r * 0.95f : r * 1.2f);
        Paint.FontMetrics fm = t.getFontMetrics();
        cv.drawText(String.valueOf(number), cx, cy - (fm.ascent + fm.descent) / 2, t);
        return b;
    }
}
